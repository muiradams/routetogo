--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.routes DROP CONSTRAINT routes_pkey;
ALTER TABLE ONLY public.airports DROP CONSTRAINT airports_pkey;
ALTER TABLE ONLY public.airlines DROP CONSTRAINT airlines_pkey;
ALTER TABLE public.routes ALTER COLUMN route_id DROP DEFAULT;
ALTER TABLE public.airports ALTER COLUMN airport_id DROP DEFAULT;
ALTER TABLE public.airlines ALTER COLUMN airline_id DROP DEFAULT;
DROP SEQUENCE public.routes_route_id_seq;
DROP TABLE public.routes;
DROP SEQUENCE public.airports_airline_id_seq;
DROP TABLE public.airports;
DROP SEQUENCE public.airlines_airline_id_seq;
DROP TABLE public.airlines;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: airlines; Type: TABLE; Schema: public; Owner: muiradams
--

CREATE TABLE airlines (
    airline_id integer NOT NULL,
    name character varying(100),
    alias character varying(50),
    iata character varying(50),
    icao character varying(50),
    callsign character varying(50),
    country character varying(50),
    active boolean
);


ALTER TABLE airlines OWNER TO muiradams;

--
-- Name: airlines_airline_id_seq; Type: SEQUENCE; Schema: public; Owner: muiradams
--

CREATE SEQUENCE airlines_airline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE airlines_airline_id_seq OWNER TO muiradams;

--
-- Name: airlines_airline_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: muiradams
--

ALTER SEQUENCE airlines_airline_id_seq OWNED BY airlines.airline_id;


--
-- Name: airports; Type: TABLE; Schema: public; Owner: muiradams
--

CREATE TABLE airports (
    airport_id integer NOT NULL,
    name character varying(100),
    city character varying(100),
    country character varying(50),
    iata character varying(4),
    icao character varying(4),
    latitude double precision,
    longitude double precision,
    altitude integer,
    timezone real,
    dst character(1),
    tz_timezone character varying(50),
    type character varying(50),
    source character varying(50)
);


ALTER TABLE airports OWNER TO muiradams;

--
-- Name: airports_airline_id_seq; Type: SEQUENCE; Schema: public; Owner: muiradams
--

CREATE SEQUENCE airports_airline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE airports_airline_id_seq OWNER TO muiradams;

--
-- Name: airports_airline_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: muiradams
--

ALTER SEQUENCE airports_airline_id_seq OWNED BY airports.airport_id;


--
-- Name: routes; Type: TABLE; Schema: public; Owner: muiradams
--

CREATE TABLE routes (
    route_id integer NOT NULL,
    airline character varying(10),
    airline_id integer,
    source_airport character varying(10),
    source_airport_id integer,
    destination_airport character varying(10),
    destination_airport_id integer,
    codeshare character varying(10),
    stops integer,
    equipment character varying(50)
);


ALTER TABLE routes OWNER TO muiradams;

--
-- Name: routes_route_id_seq; Type: SEQUENCE; Schema: public; Owner: muiradams
--

CREATE SEQUENCE routes_route_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE routes_route_id_seq OWNER TO muiradams;

--
-- Name: routes_route_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: muiradams
--

ALTER SEQUENCE routes_route_id_seq OWNED BY routes.route_id;


--
-- Name: airlines airline_id; Type: DEFAULT; Schema: public; Owner: muiradams
--

ALTER TABLE ONLY airlines ALTER COLUMN airline_id SET DEFAULT nextval('airlines_airline_id_seq'::regclass);


--
-- Name: airports airport_id; Type: DEFAULT; Schema: public; Owner: muiradams
--

ALTER TABLE ONLY airports ALTER COLUMN airport_id SET DEFAULT nextval('airports_airline_id_seq'::regclass);


--
-- Name: routes route_id; Type: DEFAULT; Schema: public; Owner: muiradams
--

ALTER TABLE ONLY routes ALTER COLUMN route_id SET DEFAULT nextval('routes_route_id_seq'::regclass);


--
-- Data for Name: airlines; Type: TABLE DATA; Schema: public; Owner: muiradams
--

COPY airlines (airline_id, name, alias, iata, icao, callsign, country, active) FROM stdin;
\.
COPY airlines (airline_id, name, alias, iata, icao, callsign, country, active) FROM '$$PATH$$/2408.dat';

--
-- Name: airlines_airline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: muiradams
--

SELECT pg_catalog.setval('airlines_airline_id_seq', 1, false);


--
-- Data for Name: airports; Type: TABLE DATA; Schema: public; Owner: muiradams
--

COPY airports (airport_id, name, city, country, iata, icao, latitude, longitude, altitude, timezone, dst, tz_timezone, type, source) FROM stdin;
\.
COPY airports (airport_id, name, city, country, iata, icao, latitude, longitude, altitude, timezone, dst, tz_timezone, type, source) FROM '$$PATH$$/2406.dat';

--
-- Name: airports_airline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: muiradams
--

SELECT pg_catalog.setval('airports_airline_id_seq', 1, false);


--
-- Data for Name: routes; Type: TABLE DATA; Schema: public; Owner: muiradams
--

COPY routes (route_id, airline, airline_id, source_airport, source_airport_id, destination_airport, destination_airport_id, codeshare, stops, equipment) FROM stdin;
\.
COPY routes (route_id, airline, airline_id, source_airport, source_airport_id, destination_airport, destination_airport_id, codeshare, stops, equipment) FROM '$$PATH$$/2410.dat';

--
-- Name: routes_route_id_seq; Type: SEQUENCE SET; Schema: public; Owner: muiradams
--

SELECT pg_catalog.setval('routes_route_id_seq', 67663, true);


--
-- Name: airlines airlines_pkey; Type: CONSTRAINT; Schema: public; Owner: muiradams
--

ALTER TABLE ONLY airlines
    ADD CONSTRAINT airlines_pkey PRIMARY KEY (airline_id);


--
-- Name: airports airports_pkey; Type: CONSTRAINT; Schema: public; Owner: muiradams
--

ALTER TABLE ONLY airports
    ADD CONSTRAINT airports_pkey PRIMARY KEY (airport_id);


--
-- Name: routes routes_pkey; Type: CONSTRAINT; Schema: public; Owner: muiradams
--

ALTER TABLE ONLY routes
    ADD CONSTRAINT routes_pkey PRIMARY KEY (route_id);


--
-- PostgreSQL database dump complete
--

